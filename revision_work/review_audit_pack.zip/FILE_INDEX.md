# review_audit_pack — FILE_INDEX

本包供外部核查，根目录对应原 `revision_work/` 目录结构。
不包含：数据集、模型权重（`weights/*.pt`）、大型逐帧预测缓存（`TEST/per_frame_predictions.jsonl` 及 `P1_*/P3/P4` 预测缓存）、环境安装目录。

## 0. 顶层文件

| 文件 | 说明 |
|---|---|
| `remediation_options.md` | 修复选项说明（对应任务第 1 项） |
| `implementation_audit.md` | 实现核查：非交织扫描输出恢复 / STF-3DConv 替换边界（任务第 2 项） |
| `preflight_report.md` | 小规模正确性检查报告（任务第 2 项） |
| `baseline_registry.json` | 旧实验逐条可用性标记（任务第 2 项） |
| `run_registry.json` | 任务状态与产物路径（任务第 3 项） |
| `resolved_experiments.json` | 解析后的实验清单（任务第 3 项） |
| `results/metrics.csv` | 正式指标长表（任务第 4 项） |
| `results/tables/*.csv` | 六类可复用结果表 CSV（任务第 4 项） |
| `writing/reviewer_coverage.md` | 审稿意见覆盖表（任务第 7 项） |
| `writing/reviewer_response_en.md` | 英文回复草稿（任务第 7 项） |

## 1. series_b 协议与运行记录

| 文件 | 说明 |
|---|---|
| `series_b/protocol.json` | 锁定协议（含 source_files/source_sha256 逐文件哈希，EMA decay/tau，checkpoint 选择规则） |
| `series_b/README.md` | 系列执行说明与命令 |
| `series_b/registry.json` | 15 个任务状态（status/counts/source_sha256） |
| `series_b/configs/*.json` | 每个任务的解析配置（model_yaml、loss、seed、config_sha256、command） |
| `series_b/configs/full.yaml` | 完整模型（Ours(n)）网络结构 |
| `series_b/configs/sste_saam.yaml` | E1 使用的 SSTE+SAAM（无 CCCBlock）网络结构 |
| `series_b/configs/stf_3dconv.yaml` | STF-3DConv 变体网络结构 |
| `series_b/source_snapshot.tar.gz` | 冻结训练/模型/数据加载/评估代码（任务第 6 项） |

## 2. 冻结代码版本 / 哈希对应关系（任务第 6 项）

- `series_b/source_snapshot.tar.gz` 的 SHA-256：`219521068c87136afb8df0abde1fe2adfc5428846f98ebe9c82916f04e711250`
- 协议级源码聚合哈希 `source_sha256`：见 `series_b/protocol.json`（顶层）及每个 `run.json`/`resolved_config.json` 内 `source_sha256` 字段。
- 逐文件哈希：见 `series_b/protocol.json` 的 `source_files`（训练/模型/数据/指标代码）与 `workflow_files_at_freeze`（队列/报表/检查脚本）。
- 代码版本：Git 仓库当前无 commit（HEAD 不存在，工作区文件仅 staged），因此以协议冻结哈希作为唯一可追溯代码版本。

## 3. 15 个正式 run（任务第 5 项）

每个 run 目录（`series_b/runs/<ID>/`）包含：
- `run.json` — 训练/模型生效配置与来源（seed、model、config_sha256、source_sha256、选中 checkpoint 路径与 SHA-256、checkpoint 选择规则、优化器步数）。
- `resolved_config.json` — 实际生效的完整解析配置（含协议、EMA、数据划分哈希、增强、评估协议）。
- `architecture.json` — 模型结构参数与各层 state 形状。
- `epochs.jsonl` — 逐 epoch 指标日志（loss 分量、样本数、batch 数、lr、EMA updates、耗时）。
- `train.stdout.log` / `TEST.stdout.log` — 训练与正式测试 stdout/stderr。
- `progress.json` — 最终进度快照。
- `TEST/run.json`、`TEST/evaluation.json` — 正式 TEST 原始结果（metrics、样本数、逐序列误报、预测缓存哈希、尺寸分组）。

### 逐 run 汇总

| ID | model | seed | epoch | config_sha256(前12) | checkpoint_sha256(前12) | checkpoint选择(epoch/EMA) | AP50 | AP50-95 | test样本 |
|---|---|---|---|---|---|---|---|---|---|
| `B_3DCONV_0` | stf_3dconv | 0 | 100 | `bcf723c343af` | `9eb75e6a2d1f` | EMA of fixed final epoch 100 (EMA decay=0.9999) | 0.8663967434147912 | 0.6176069777665945 | 4795 |
| `B_FULL_0` | full | 0 | 100 | `50ea5eadca9e` | `2400fdbcd7fb` | EMA of fixed final epoch 100 (EMA decay=0.9999) | 0.8465799244880756 | 0.5779877934537649 | 4795 |
| `E1` | sste_saam | 0 | 100 | `a5bfde7161a3` | `48b1ee355258` | EMA of fixed final epoch 100 (EMA decay=0.9999) | 0.854843472475955 | 0.6052482780206134 | 4795 |
| `E2` | full | 0 | 100 | `d72ea1511088` | `19ff944dfed7` | EMA of fixed final epoch 100 (EMA decay=0.9999) | 0.8682337596386238 | 0.615284409185276 | 4795 |
| `E3` | full | 0 | 100 | `c7dc59b94aa7` | `e8b6b0de4439` | EMA of fixed final epoch 100 (EMA decay=0.9999) | 0.9154839434799673 | 0.637774120318868 | 4795 |
| `E4` | full | 0 | 100 | `41576f8d8dd8` | `f0e729c34204` | EMA of fixed final epoch 100 (EMA decay=0.9999) | 0.9008304728931124 | 0.6133150733431668 | 4795 |
| `E5` | full | 0 | 100 | `568e77bbf404` | `ec7546a845f3` | EMA of fixed final epoch 100 (EMA decay=0.9999) | 0.8798774155919813 | 0.6151083714349792 | 4795 |
| `E6` | full | 0 | 100 | `a622b313e6df` | `81050de6dcbd` | EMA of fixed final epoch 100 (EMA decay=0.9999) | 0.8709325535463157 | 0.6136220842081137 | 4795 |
| `E7` | full | 0 | 100 | `35983dcc4331` | `ba751fb39fc2` | EMA of fixed final epoch 100 (EMA decay=0.9999) | 0.8777689686285292 | 0.6220199357108427 | 4795 |
| `E8` | full | 0 | 100 | `60fa4095ca8a` | `92a5e3006c03` | EMA of fixed final epoch 100 (EMA decay=0.9999) | 0.8877960200078858 | 0.6239983049904213 | 4795 |
| `E9` | full | 0 | 100 | `3efd6a593ec7` | `af12d2531404` | EMA of fixed final epoch 100 (EMA decay=0.9999) | 0.9036407176764711 | 0.6203261193718198 | 4795 |
| `R1` | full | 2027 | 100 | `32c113b674a7` | `75a4b196553d` | EMA of fixed final epoch 100 (EMA decay=0.9999) | 0.8430662031147345 | 0.602732862975183 | 4795 |
| `R2` | stf_3dconv | 2027 | 100 | `89e28e625333` | `24e408d865ff` | EMA of fixed final epoch 100 (EMA decay=0.9999) | 0.8469643234931632 | 0.5910087681969641 | 4795 |
| `R3` | full | 3407 | 100 | `81820c673fe6` | `50fe834b064f` | EMA of fixed final epoch 100 (EMA decay=0.9999) | 0.849922778256143 | 0.6071746563359688 | 4795 |
| `R4` | stf_3dconv | 3407 | 100 | `90dad8cac3c7` | `154612b9a445` | EMA of fixed final epoch 100 (EMA decay=0.9999) | 0.8661703600900219 | 0.6136456766412262 | 4795 |

说明：完整 checkpoint 哈希、EMA decay/tau、loss 系数、kernel 等完整值见各 run 的 `run.json` 与 `resolved_config.json`。

## 4. 未包含内容（按任务要求排除）

- `weights/*.pt`（模型权重，78 MB×约90 文件）；选中 checkpoint 的哈希/epoch/EMA 信息已记录于 `run.json`。
- `TEST/per_frame_predictions.jsonl` 及 `P1_s*/P3/P4` 的逐帧预测缓存（大型预测缓存）；其汇总已进入 `results/tables/*.csv`，逐序列指标在 `TEST/evaluation.json`。
- 数据集图像与清单（DAUB/NUDT-MIRSDT 原始帧）。
- 环境/解释器安装目录。
