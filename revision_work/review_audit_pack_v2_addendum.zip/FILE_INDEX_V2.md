# review_audit_pack_v2_addendum — FILE_INDEX_V2

本包是第一份 `review_audit_pack.zip`（v1）的**补遗**，只补导出现有证据、更新状态文档，未启动任何新增训练、未调参、未换数据、未改冻结模型/训练代码。根目录仍对应原 `revision_work/`。

## 三层状态（重要）

1. **已生成运行实物**：run.json / epochs.jsonl / TEST/evaluation.json / P1/P3/P4 记录 / 预检实物等机器记录，可独立核查。
2. **汇总一致**：`results/metrics.csv`、`results/tables/*`、`series_b/registry.json` 由上述产物自动汇总，字段一致。
3. **独立复算 / 外部核验**：尚未完成。`formal=True` / `verified` 仅表示本协议内部状态机通过，**不代表第三方已独立复算 AP**。

## 代码版本 / 运行时哈希

- Git 仓库无 commit（HEAD 不存在），代码版本以冻结哈希为准。
- v1 训练/模型/数据/评估代码：`series_b/source_snapshot.tar.gz`，聚合 `source_sha256=bdbe7bc9…`（见 v1 的 `series_b/protocol.json`）。
- 外部评估代码：`series_b/external_source_snapshot.tar.gz`（本包），其中 `external.py` SHA-256 与当前工作区 `new_protocol/external.py` 一致（见下表），即冻结快照==当前版本；因无法回放当时进程内存，只能证明“当前文件与冻结运行时快照一致”，不能独立证明另有不同运行时版本。
- `external.py` 导入的本地辅助模块 `common.py` / `data.py` / `evaluate.py` 均已在 v1 冻结源码包内，且当前哈希与 v1 冻结哈希一致（common `eb165967…`、data `2b8dbf5f…`、evaluate `e5939c54…`），无需重复导出。

## 文件清单

| 包内路径 | 真实源路径 | 大小(bytes) | SHA-256 | 任务 | 与 v1 关系 | 说明 |
|---|---|---|---|---|---|---|
| `evidence/data/DAUB_train_frames.jsonl` | `/home/dell/lxs/tsgmamba/ultralytics-main/revision_work/evidence/data/DAUB_train_frames.jsonl` | 4268259 | `271fc15f67050490…` | A1 | 新增 | 训练关键帧与标注清单（8982 帧） |
| `evidence/data/DAUB_val_frames.jsonl` | `/home/dell/lxs/tsgmamba/ultralytics-main/revision_work/evidence/data/DAUB_val_frames.jsonl` | 2273211 | `82bcc58e16fdced4…` | A1 | 新增 | 测试关键帧与标注清单（4795 帧） |
| `evidence/data/DAUB_val_temporal_common.json` | `/home/dell/lxs/tsgmamba/ultralytics-main/revision_work/evidence/data/DAUB_val_temporal_common.json` | 7623750 | `69f06de9e715b1f3…` | A1 | 新增 | P1 共同关键帧集合（每 stride 4683 帧，i≥16） |
| `evidence/data/summary.json` | `/home/dell/lxs/tsgmamba/ultralytics-main/revision_work/evidence/data/summary.json` | 3110 | `b41d2d81688e227e…` | A1 | 新增 | 序列不重叠（train__val 交集为空）与标注尺寸分组统计 |
| `evidence/data/DAUB_train_sequences.json` | `/home/dell/lxs/tsgmamba/ultralytics-main/revision_work/evidence/data/DAUB_train_sequences.json` | 1218 | `66b85fd5422dd494…` | A1 | 新增 | 训练序列清单（10 序列，帧区间/缺失帧） |
| `evidence/data/DAUB_val_sequences.json` | `/home/dell/lxs/tsgmamba/ultralytics-main/revision_work/evidence/data/DAUB_val_sequences.json` | 851 | `db7ea8ebcee6d854…` | A1 | 新增 | 测试序列清单（7 序列，帧区间/缺失帧） |
| `grouping_lock.json` | `/home/dell/lxs/tsgmamba/ultralytics-main/revision_work/grouping_lock.json` | 1017 | `57d3dc98d4caaddb…` | A1 | 新增 | 标注尺寸分组冻结（d≤3 / 3<d≤7 / d>7） |
| `series_b/preflight/result.json` | `/home/dell/lxs/tsgmamba/ultralytics-main/revision_work/series_b/preflight/result.json` | 216841 | `c048687d9203ef2e…` | A2 | 新增 | 新协议预检总结果（formal_training=false，passed=true） |
| `series_b/preflight/B_FULL_0.json` | `/home/dell/lxs/tsgmamba/ultralytics-main/revision_work/series_b/preflight/B_FULL_0.json` | 38034 | `2a148afbbd039078…` | A2 | 新增 | B_FULL_0 逐模型预检 JSON |
| `series_b/preflight/B_3DCONV_0.json` | `/home/dell/lxs/tsgmamba/ultralytics-main/revision_work/series_b/preflight/B_3DCONV_0.json` | 34393 | `333b4c92cf262242…` | A2 | 新增 | B_3DCONV_0 逐模型预检 JSON |
| `series_b/preflight/E1.json` | `/home/dell/lxs/tsgmamba/ultralytics-main/revision_work/series_b/preflight/E1.json` | 33462 | `a4fb5b61a0696783…` | A2 | 新增 | E1 逐模型预检 JSON |
| `series_b/preflight/E2.json` | `/home/dell/lxs/tsgmamba/ultralytics-main/revision_work/series_b/preflight/E2.json` | 36799 | `2b7c599d60fda754…` | A2 | 新增 | E2 逐模型预检 JSON |
| `series_b/preflight/E3.json` | `/home/dell/lxs/tsgmamba/ultralytics-main/revision_work/series_b/preflight/E3.json` | 36804 | `1946b07184772f23…` | A2 | 新增 | E3 逐模型预检 JSON |
| `series_b/runs/B_FULL_0/P1_s1/run.json` | `/home/dell/lxs/tsgmamba/ultralytics-main/revision_work/series_b/runs/B_FULL_0/P1_s1/run.json` | 2787 | `3992b6fba791fda9…` | A3 | 新增 | B_FULL_0 P1 stride=1 run 记录 |
| `series_b/runs/B_FULL_0/P1_s1/evaluation.json` | `/home/dell/lxs/tsgmamba/ultralytics-main/revision_work/series_b/runs/B_FULL_0/P1_s1/evaluation.json` | 1881 | `8adcb577f551e171…` | A3 | 新增 | B_FULL_0 P1 stride=1 评估结果 |
| `series_b/runs/B_FULL_0/P1_s1.stdout.log` | `/home/dell/lxs/tsgmamba/ultralytics-main/revision_work/series_b/runs/B_FULL_0/P1_s1.stdout.log` | 726 | `d9cec2d15f752e3e…` | A3 | 新增 | B_FULL_0 P1 stride=1 stdout |
| `series_b/runs/B_FULL_0/P1_s2/run.json` | `/home/dell/lxs/tsgmamba/ultralytics-main/revision_work/series_b/runs/B_FULL_0/P1_s2/run.json` | 2781 | `cf9aaef2f784cc40…` | A3 | 新增 | B_FULL_0 P1 stride=2 run 记录 |
| `series_b/runs/B_FULL_0/P1_s2/evaluation.json` | `/home/dell/lxs/tsgmamba/ultralytics-main/revision_work/series_b/runs/B_FULL_0/P1_s2/evaluation.json` | 1875 | `c8adffa056e77ef7…` | A3 | 新增 | B_FULL_0 P1 stride=2 评估结果 |
| `series_b/runs/B_FULL_0/P1_s2.stdout.log` | `/home/dell/lxs/tsgmamba/ultralytics-main/revision_work/series_b/runs/B_FULL_0/P1_s2.stdout.log` | 726 | `552b32c8f7d889d0…` | A3 | 新增 | B_FULL_0 P1 stride=2 stdout |
| `series_b/runs/B_FULL_0/P1_s4/run.json` | `/home/dell/lxs/tsgmamba/ultralytics-main/revision_work/series_b/runs/B_FULL_0/P1_s4/run.json` | 2791 | `573a8f3e544aeb83…` | A3 | 新增 | B_FULL_0 P1 stride=4 run 记录 |
| `series_b/runs/B_FULL_0/P1_s4/evaluation.json` | `/home/dell/lxs/tsgmamba/ultralytics-main/revision_work/series_b/runs/B_FULL_0/P1_s4/evaluation.json` | 1885 | `cd96fa106890b547…` | A3 | 新增 | B_FULL_0 P1 stride=4 评估结果 |
| `series_b/runs/B_FULL_0/P1_s4.stdout.log` | `/home/dell/lxs/tsgmamba/ultralytics-main/revision_work/series_b/runs/B_FULL_0/P1_s4.stdout.log` | 726 | `0a090470ed22d810…` | A3 | 新增 | B_FULL_0 P1 stride=4 stdout |
| `series_b/runs/B_FULL_0/P3/run.json` | `/home/dell/lxs/tsgmamba/ultralytics-main/revision_work/series_b/runs/B_FULL_0/P3/run.json` | 4797 | `4b96c1dfd3698ea1…` | A3 | 新增 | B_FULL_0 P3 外部测试 run 记录 |
| `series_b/runs/B_FULL_0/P3/evaluation.json` | `/home/dell/lxs/tsgmamba/ultralytics-main/revision_work/series_b/runs/B_FULL_0/P3/evaluation.json` | 3292 | `f661b992333ffc5f…` | A3 | 新增 | B_FULL_0 P3 外部测试评估结果 |
| `series_b/runs/B_FULL_0/P3.stdout.log` | `/home/dell/lxs/tsgmamba/ultralytics-main/revision_work/series_b/runs/B_FULL_0/P3.stdout.log` | 505 | `a3185ce7c91801eb…` | A3 | 新增 | B_FULL_0 P3 stdout |
| `series_b/runs/B_FULL_0/P4/run.json` | `/home/dell/lxs/tsgmamba/ultralytics-main/revision_work/series_b/runs/B_FULL_0/P4/run.json` | 23980 | `6223e6359dd1f38f…` | A3 | 新增 | B_FULL_0 P4 run 记录（含 950 次原始计时 latency_ms） |
| `series_b/runs/B_FULL_0/P4.stdout.log` | `/home/dell/lxs/tsgmamba/ultralytics-main/revision_work/series_b/runs/B_FULL_0/P4.stdout.log` | 380 | `dabfce78d4c502d6…` | A3 | 新增 | B_FULL_0 P4 stdout |
| `series_b/runs/B_3DCONV_0/P1_s1/run.json` | `/home/dell/lxs/tsgmamba/ultralytics-main/revision_work/series_b/runs/B_3DCONV_0/P1_s1/run.json` | 2802 | `ef48e5440d79c647…` | A3 | 新增 | B_3DCONV_0 P1 stride=1 run 记录 |
| `series_b/runs/B_3DCONV_0/P1_s1/evaluation.json` | `/home/dell/lxs/tsgmamba/ultralytics-main/revision_work/series_b/runs/B_3DCONV_0/P1_s1/evaluation.json` | 1890 | `12f5a3c96a83bfd6…` | A3 | 新增 | B_3DCONV_0 P1 stride=1 评估结果 |
| `series_b/runs/B_3DCONV_0/P1_s1.stdout.log` | `/home/dell/lxs/tsgmamba/ultralytics-main/revision_work/series_b/runs/B_3DCONV_0/P1_s1.stdout.log` | 728 | `eae3843acdd9d219…` | A3 | 新增 | B_3DCONV_0 P1 stride=1 stdout |
| `series_b/runs/B_3DCONV_0/P1_s2/run.json` | `/home/dell/lxs/tsgmamba/ultralytics-main/revision_work/series_b/runs/B_3DCONV_0/P1_s2/run.json` | 2799 | `2c6400f99cf14672…` | A3 | 新增 | B_3DCONV_0 P1 stride=2 run 记录 |
| `series_b/runs/B_3DCONV_0/P1_s2/evaluation.json` | `/home/dell/lxs/tsgmamba/ultralytics-main/revision_work/series_b/runs/B_3DCONV_0/P1_s2/evaluation.json` | 1887 | `da205409d8f253ea…` | A3 | 新增 | B_3DCONV_0 P1 stride=2 评估结果 |
| `series_b/runs/B_3DCONV_0/P1_s2.stdout.log` | `/home/dell/lxs/tsgmamba/ultralytics-main/revision_work/series_b/runs/B_3DCONV_0/P1_s2.stdout.log` | 728 | `466f6acd2ec16ee4…` | A3 | 新增 | B_3DCONV_0 P1 stride=2 stdout |
| `series_b/runs/B_3DCONV_0/P1_s4/run.json` | `/home/dell/lxs/tsgmamba/ultralytics-main/revision_work/series_b/runs/B_3DCONV_0/P1_s4/run.json` | 2804 | `714e4cd2de3dcf14…` | A3 | 新增 | B_3DCONV_0 P1 stride=4 run 记录 |
| `series_b/runs/B_3DCONV_0/P1_s4/evaluation.json` | `/home/dell/lxs/tsgmamba/ultralytics-main/revision_work/series_b/runs/B_3DCONV_0/P1_s4/evaluation.json` | 1892 | `5305bf1968393842…` | A3 | 新增 | B_3DCONV_0 P1 stride=4 评估结果 |
| `series_b/runs/B_3DCONV_0/P1_s4.stdout.log` | `/home/dell/lxs/tsgmamba/ultralytics-main/revision_work/series_b/runs/B_3DCONV_0/P1_s4.stdout.log` | 728 | `b8059763eeb76358…` | A3 | 新增 | B_3DCONV_0 P1 stride=4 stdout |
| `series_b/runs/B_3DCONV_0/P3/run.json` | `/home/dell/lxs/tsgmamba/ultralytics-main/revision_work/series_b/runs/B_3DCONV_0/P3/run.json` | 4802 | `58212800ae284152…` | A3 | 新增 | B_3DCONV_0 P3 外部测试 run 记录 |
| `series_b/runs/B_3DCONV_0/P3/evaluation.json` | `/home/dell/lxs/tsgmamba/ultralytics-main/revision_work/series_b/runs/B_3DCONV_0/P3/evaluation.json` | 3291 | `46d68b7fcb7d0d8e…` | A3 | 新增 | B_3DCONV_0 P3 外部测试评估结果 |
| `series_b/runs/B_3DCONV_0/P3.stdout.log` | `/home/dell/lxs/tsgmamba/ultralytics-main/revision_work/series_b/runs/B_3DCONV_0/P3.stdout.log` | 507 | `d8fadf978ddf283c…` | A3 | 新增 | B_3DCONV_0 P3 stdout |
| `series_b/runs/B_3DCONV_0/P4/run.json` | `/home/dell/lxs/tsgmamba/ultralytics-main/revision_work/series_b/runs/B_3DCONV_0/P4/run.json` | 23240 | `d1dc8aac6a2f696d…` | A3 | 新增 | B_3DCONV_0 P4 run 记录（含 950 次原始计时 latency_ms） |
| `series_b/runs/B_3DCONV_0/P4.stdout.log` | `/home/dell/lxs/tsgmamba/ultralytics-main/revision_work/series_b/runs/B_3DCONV_0/P4.stdout.log` | 382 | `a12c9a1b247809c0…` | A3 | 新增 | B_3DCONV_0 P4 stdout |
| `new_protocol/external.py` | `/home/dell/lxs/tsgmamba/ultralytics-main/revision_work/new_protocol/external.py` | 14466 | `a9d874c59a12ddda…` | A4 | 新增 | 实际使用的外部评估入口（当前版本，未含于 v1 冻结源码包） |
| `series_b/external_source_snapshot.tar.gz` | `/home/dell/lxs/tsgmamba/ultralytics-main/revision_work/series_b/external_source_snapshot.tar.gz` | 334332 | `bc361e5d2810a6cb…` | A4 | 新增 | 外部评估冻结代码/协议/官方划分快照（运行时版本） |
| `series_b/external/protocol.json` | `/home/dell/lxs/tsgmamba/ultralytics-main/revision_work/series_b/external/protocol.json` | 5213 | `51b40ffe064d59ed…` | A4 | 新增 | 外部评估锁定协议（官方清单哈希、2000 测试关键帧、mask→框规则） |
| `series_b/external/overlap_audit.json` | `/home/dell/lxs/tsgmamba/ultralytics-main/revision_work/series_b/external/overlap_audit.json` | 659 | `2b59335b6ac688f3…` | A4 | 新增 | 与 DAUB 13777 张图像解码像素重叠审计 |
| `series_b/external/NUDT-MIRSDT_test_frames.jsonl` | `/home/dell/lxs/tsgmamba/ultralytics-main/revision_work/series_b/external/NUDT-MIRSDT_test_frames.jsonl` | 1530237 | `67489bd731dbf2c9…` | A4 | 新增 | 冻结样本/标注清单（2000 测试关键帧） |
| `evidence/external/NUDT-MIRSDT/train.txt` | `/home/dell/lxs/tsgmamba/ultralytics-main/revision_work/evidence/external/NUDT-MIRSDT/train.txt` | 199100 | `31e71368775adbc6…` | A4 | 新增 | 官方训练划分（8000 帧/80 序列） |
| `evidence/external/NUDT-MIRSDT/test.txt` | `/home/dell/lxs/tsgmamba/ultralytics-main/revision_work/evidence/external/NUDT-MIRSDT/test.txt` | 50300 | `eb039aa35aaabab2…` | A4 | 新增 | 官方测试划分（2000 帧/20 序列） |
| `evidence/external/NUDT-MIRSDT/source_audit.json` | `/home/dell/lxs/tsgmamba/ultralytics-main/revision_work/evidence/external/NUDT-MIRSDT/source_audit.json` | 4766 | `d39360771fbe5723…` | A4 | 新增 | 官方划分/README/数据加载器抓取哈希与序列清单 |
| `evidence/external/NUDT-MIRSDT/download.json` | `/home/dell/lxs/tsgmamba/ultralytics-main/revision_work/evidence/external/NUDT-MIRSDT/download.json` | 530 | `6d1bff754924efae…` | A4 | 新增 | 官方包下载记录（zip sha256） |
| `evidence/external/NUDT-MIRSDT/README.md` | `/home/dell/lxs/tsgmamba/ultralytics-main/revision_work/evidence/external/NUDT-MIRSDT/README.md` | 4358 | `fd7721146b590bf9…` | A4 | 新增 | 官方仓库 README（划分/SNR 子集说明） |
| `evidence/external/NUDT-MIRSDT/MIRSDTDataLoader.py` | `/home/dell/lxs/tsgmamba/ultralytics-main/revision_work/evidence/external/NUDT-MIRSDT/MIRSDTDataLoader.py` | 4845 | `1c96824ae74f993b…` | A4 | 新增 | 官方数据加载器源码 |
| `writing/technical_comparison.md` | `/home/dell/lxs/tsgmamba/ultralytics-main/revision_work/writing/technical_comparison.md` | 3996 | `5ef9840f8309c7fa…` | A5 | 新增 | 六篇一手方法技术比较 |
| `writing/series_b_results_en.md` | `/home/dell/lxs/tsgmamba/ultralytics-main/revision_work/writing/series_b_results_en.md` | 1867 | `28ebdd4e48948429…` | A5 | 新增 | 方案 B 结果草稿（15 次训练/三 seed/P3 结果） |
| `writing/reviewer_coverage.md` | `/home/dell/lxs/tsgmamba/ultralytics-main/revision_work/writing/reviewer_coverage.md` | 3230 | `5ba4b23fae43ef16…` | C | 更新版 | 审稿覆盖表（已更新：15 次、三 seed、缺口与三层状态） |
| `writing/reviewer_response_en.md` | `/home/dell/lxs/tsgmamba/ultralytics-main/revision_work/writing/reviewer_response_en.md` | 5917 | `ca4e691c979c52a5…` | C | 更新版 | 英文回复（已更新：移除 zero formal repeat / 无三 seed 统计等过时表述） |
| `implementation_audit.md` | `/home/dell/lxs/tsgmamba/ultralytics-main/revision_work/implementation_audit.md` | 7880 | `ebca98ebeded36d4…` | C | 更新版 | 实现审计（已标注为前期历史审计并补新阶段说明） |
| `preflight_report.md` | `/home/dell/lxs/tsgmamba/ultralytics-main/revision_work/preflight_report.md` | 2296 | `b6c6835d8aaba1fe…` | C | 更新版 | 正确性检查（已标注为前期历史审计并补新阶段说明） |
| `执行情况汇报.md` | `/home/dell/lxs/tsgmamba/ultralytics-main/revision_work/执行情况汇报.md` | 12284 | `10e1023135030c99…` | C | 更新版 | 执行汇报（resolved_experiments 13→15 表述已修正） |

### B 项：三个正式 TEST 逐帧缓存（gzip）

| 包内路径 | 原始行数 | 原始 SHA-256 | gz SHA-256 | gz 大小 |
|---|---|---|---|---|
| `series_b/runs/B_FULL_0/TEST/per_frame_predictions.jsonl.gz` | 4795 | `5312ed31dd78cd7d…` | `a8e750d44d09c94e…` | 322431 |
| `series_b/runs/B_3DCONV_0/TEST/per_frame_predictions.jsonl.gz` | 4795 | `21c0dd84be92822c…` | `25cae1328e24307b…` | 301565 |
| `series_b/runs/E3/TEST/per_frame_predictions.jsonl.gz` | 4795 | `a103fd3f3250bd59…` | `5ffb45fb9bfe2312…` | 324305 |

缓存保留全部帧（含空预测行 `"boxes_xyxy": []`），未挑选、未去重、不含 checkpoint 权重。

## 坐标与正式 AP 的关系（B 项说明）

- 缓存中的 `boxes_xyxy` 来自 `evaluate.py` 的 `validator.scale_preds(pred, prepared)`，是**原图（letterbox 反变换后）坐标**；每条还存 `original_hw`、`clip_files`、`confidences`、`classes`、`seq_id`、`frame_id`。
- 正式 AP 由 ultralytics `DetectionValidator` 在 **letterbox 输入坐标**内匹配：`_prepare_batch` 将 GT 乘以 `imgsz` 变换到 640×640 letterbox 空间，`_prepare_pred` 保留预测在 letterbox 空间，随后 `_process_batch` 匹配。
- 因此仅凭缓存中已反变换的原图框，无法“肉眼/直接”严格复算原 AP：中间 letterbox 框未写入缓存。可复算路径是：用冻结的 `evaluate.py` + `ultralytics/models/yolo/detect/val.py` 的确定性 letterbox 变换与 DetMetrics 匹配，配合 `evidence/data/DAUB_val_frames.jsonl` 的 GT 与缓存中的置信度/类别。本轮**未**为此重跑推理，也未改动原指标。

## 过时状态缓存说明（C 项，未改历史文件）

- `series_b/queue.json` 与 `series_b/registry.json` 已为终态：`running=0`、`trained=15`、`test_verified=15`、`failed=0`。
- 各 run 的 `progress.json` 内 `status` 字段是训练进程最后一次写盘的快照（部分仍显示 `running`），属过时值；以各 run 的 `run.json`（`status=trained`、`epoch_completed=100`）与 `TEST/run.json`（`status=verified`）及 `series_b/registry.json`（`verified`）为准。原始训练日志与指标未改动。

## 与 v1 的关系

- v1 已含：series_b 协议/README/registry、顶层审计/预检/注册表、results、15 个 run 的训练配置/逐 epoch 日志/TEST 结果、冻结训练代码、writing 的 coverage/response。
- 本补遗新增：DAUB 数据与统计证据、新协议预检实物、P1/P3/P4 结果、外部评估代码与官方划分、3 个 TEST 逐帧缓存（gzip）、technical_comparison / series_b_results_en、以及更新后的 coverage/response/审计/预检/汇报文档。
