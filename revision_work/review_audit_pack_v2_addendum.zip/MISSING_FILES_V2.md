# review_audit_pack_v2_addendum — MISSING_FILES_V2

以下为本轮指令要求但工作区中确实找不到的文件，未补造内容：

| 缺失文件 | 指令出处 | 影响 |
|---|---|---|
| `codex/REVIEWER_ACCEPTANCE.md` | C 项（用用户补回的真实 R1.1–R2.4） | 已搜索 `/home/dell/lxs`、`/home/dell`（含 codex/、revision_work/），未找到；无法逐条还原 R1.1–R2.4 的确切编号与验收要求，任何实际审稿条目都未标为已处理 |
| `codex/experiment_manifest.json` | C 项（不要用旧 13 次 manifest 覆盖 15 次记录） | 缺失；本包以 `resolved_experiments.json`（15 个任务）为权威，`taskbook_derived_manifest.json` 仅为 13 槽位派生存根（authoritative=false） |
| `series_b/runs/B_FULL_0/P4/evaluation.json` | A3（P4 保留 950 次原始计时；本无 evaluation.json 则列明） | P4 是速度/显存基准，无 evaluation.json；950 次原始计时在 `P4/run.json` 的 `latency_ms`（len=950），未补造 |
| `series_b/runs/B_3DCONV_0/P4/evaluation.json` | 同上 | 同上；数据在 `P4/run.json` |
| `series_b/preflight/E4–E9、R1–R4 逐模型预检 JSON` | A2（该目录内逐模型预检 JSON） | 目录中仅有 B_FULL_0/B_3DCONV_0/E1/E2/E3 五个逐模型预检 JSON；E4–E9 复用 B_FULL_0 结构、R1–R4 复用 B_FULL_0/B_3DCONV_0 结构，预检只覆盖受影响变体，属预期不存在，非遗漏 |

已确认存在并纳入本包的文件见 `FILE_INDEX_V2.md`。
